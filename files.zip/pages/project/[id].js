import { useRouter } from 'next/router';
import projects from '../../data/projects.json';

export default function ProjectDetails() {
  const router = useRouter();
  const { id } = router.query;
  const project = projects.find((p) => p.id.toString() === id);

  if (!project) {
    return <p>加载中...</p>;
  }

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-4xl font-bold">{project.title}</h1>
      <img src={project.image} alt={project.title} className="w-full h-64 object-cover mt-4" />
      <p className="mt-4 text-gray-700">{project.details.process}</p>
      <p className="mt-4 text-gray-700">技术: {project.details.tech}</p>
      <a href={project.details.externalLink} className="text-blue-500 mt-4 inline-block">
        外部链接
      </a>
    </div>
  );
}