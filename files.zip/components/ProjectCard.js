import Link from 'next/link';

const ProjectCard = ({ project }) => {
  return (
    <div className="border rounded-lg p-4 shadow-md">
      <img src={project.image} alt={project.name} className="w-full h-48 object-cover rounded-md" />
      <h2 className="text-xl font-semibold mt-2">{project.name}</h2>
      <p className="text-gray-600">by {project.author}</p>
      <p className="mt-2">{project.description}</p>
      <Link href={`/project/${project.id}`}>
        <a className="inline-block mt-4 text-blue-500">View Details</a>
      </Link>
    </div>
  );
};

export default ProjectCard;