import Link from 'next/link';

export default function Header() {
  return (
    <header className="bg-gray-800 text-white py-4">
      <div className="container mx-auto flex justify-between items-center">
        <h1 className="text-2xl font-bold">项目分享网站</h1>
        <nav>
          <Link href="/">
            <a className="px-4">首页</a>
          </Link>
        </nav>
      </div>
    </header>
  );
}