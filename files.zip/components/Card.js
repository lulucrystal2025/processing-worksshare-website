import Link from 'next/link';

export default function Card({ project }) {
  return (
    <div className="border rounded-lg shadow-md overflow-hidden">
      <img src={project.image} alt={project.title} className="w-full h-48 object-cover" />
      <div className="p-4">
        <h2 className="text-xl font-bold">{project.title}</h2>
        <p className="text-gray-600">作者: {project.author}</p>
        <p className="text-gray-700 mt-2">{project.description}</p>
        <Link href={`/project/${project.id}`}>
          <a className="text-blue-500 mt-4 inline-block">查看详情</a>
        </Link>
      </div>
    </div>
  );
}